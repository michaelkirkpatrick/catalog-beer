# API Basics

Base URL: `https://api.catalog.beer` — HTTPS required; plain HTTP fails.

Headers on every request:

- `Accept: application/json`
- `Content-Type: application/json` on POST/PUT/PATCH (bodies are JSON)

## Authentication

HTTP Basic. The API key is the username, the password is blank:

```
Authorization: Basic base64("{api_key}:")
```

With curl: `-u "$CATALOG_BEER_API_KEY:"` (note the trailing colon).

Accounts are created on the website, not the API: sign up at https://catalog.beer/signup, verify email, key at https://catalog.beer/account. The key is `null` until the email is verified (`GET /users/{id}/api-key` returns `api_key: null`).

## HTTP method semantics

| Method | Semantics |
|---|---|
| GET | Retrieve resource or list |
| POST | Create a new resource |
| PUT | **Full replacement.** All required fields must be present. Omitted optional fields are **cleared to null**. Upsert: creates if missing → `201`, replaces if exists → `200` |
| PATCH | Partial update; only provided fields change. Resource must exist → `404` otherwise |
| DELETE | Removes resource → `204 No Content`, no body |

`405 Method Not Allowed` if the endpoint doesn't support the method; the `Allow` response header lists what it does support.

## Errors

Error responses are JSON:

| Field | Type | Notes |
|---|---|---|
| `error` | boolean | |
| `error_msg` | string | optional human-readable message |
| `valid_state` | object | optional; per-field `"valid"` / `"invalid"` |
| `valid_msg` | object | optional; per-field explanation of what's wrong |

Example (invalid POST /brewer):

```json
{
  "error": true,
  "error_msg": "",
  "valid_state": {"name": "invalid", "url": "valid", "description": "valid", "short_description": "valid"},
  "valid_msg": {"name": "Please give us the name of the brewery you'd like to add.", "url": "", "description": "", "short_description": ""}
}
```

Read `valid_msg` for the failing field — it says exactly what to fix.

## Usage limits & billing

- Each key includes **1,000 free requests/month**, plus a small grace buffer. The counter resets on the 1st of each month (Pacific time).
- With a payment method on file (added by the user at https://catalog.beer/billing), the key keeps working past the free tier at **$1 per 1,000 requests**, rounded up to whole blocks and invoiced monthly — bounded by a per-key monthly spend cap ($50 by default).
- Without a payment method, exceeding limit + buffer → `402 Payment Required` until the month resets. With one, a `402` appears only once the month's usage would cost more than the spend cap. The `error_msg` says which case applies.
- A `402` is a monthly allowance, not a pace limit — there is no per-second or per-minute throttle. **Do not retry or back off**: the wall stands until the user pays or the month resets. Stop and report.
- `GET /usage/my-usage` (usage object: `year`, `month`, `count`, `request_limit`, `request_buffer`, `resets_on`, `last_updated`) and everything under `/billing` are never blocked by the usage limit and don't count toward usage — always safe to check. Neither response echoes the API key, so printing them cannot leak it.
- Pricing details: https://catalog.beer/api-pricing

### Billing endpoints

| Endpoint | What it does |
|---|---|
| `GET /billing` | Billing status for the key: `billing_enabled`, `monthly_spend_cap_cents`, `card` (brand/last4, or `null`), plus this month's `count`, `request_limit`, `billable_requests`, `estimated_charge_cents`, `unbilled_balance_cents` |
| `PATCH /billing` | Body: `monthly_spend_cap_cents` — `0` (block all paid usage) or `100`–`100000` ($1–$1,000) |
| `DELETE /billing` | Turns billing off; the key returns to the free-tier cap. The card stays saved with Stripe |

**These endpoints spend the user's money — only call them when the user explicitly asks.** Never raise a spend cap or disable billing on your own initiative. Adding or managing a payment method happens on the website, not through the API. If a key hits its free-tier `402` mid-task, stop and tell the user their options — wait for the monthly reset, or add a payment method at https://catalog.beer/billing — rather than "fixing" it yourself.

## Pagination

Cursor-based. List responses:

```json
{"object": "list", "url": "/brewer", "has_more": true, "next_cursor": "...", "data": [...]}
```

- Pass `next_cursor` back as the `cursor` query param to get the next page.
- `next_cursor` is only present when `has_more` is `true`.
- `count` query param controls page size. Defaults: 500 for `/brewer`, `/beer`, `/location`; 25 (max 100) for `*/search`; 100 for `/location/nearby|zip|city`.
- URL-encode query values (everything except alphanumerics, `-`, `_`).

## Syncing a copy of the catalog

`GET /brewer`, `GET /beer` and `GET /location` take `modified_since=<unix seconds>` and return only the rows whose `last_modified` is at or after it, paged like the full list; the response echoes the value as `modified_since`. To refresh a local copy: note the current time before the run, page each of the three lists with the *previous* run's time, fetch every id returned (`GET /brewer/{id}` and so on), then store the new time. The comparison is inclusive, so a record can show up in two consecutive runs; that is harmless. A malformed value (anything but digits, the empty string included) is a `400`, never the whole catalog. Deletes are not reported — a `404` on the entity is the only signal, and the full unfiltered list is the authoritative set of ids. A beer's or location's `last_modified` does not move when its brewer's does, so page all three lists.

## IDs

Entity IDs (beer, brewer, location, user) are 36-character UUIDs. Style IDs are human-readable slugs (`american-ipa`). `last_modified` fields are Unix timestamps (integers).
